const express = require('express')
const app = express()
const path = require('path')
const usermodel = require('./models/user')
const Bookmodel = require('./models/book')
const book = require('./models/book')

app.use(express.static(path.join(__dirname, 'public')));

app.use(express.json())
app.use(express.urlencoded({extended:true}))

app.set('view engine' , 'ejs')
 
app.get('/',(req,res)=>{
    res.render('index')
})
// creating user 

app.post('/create',  async (req,res)=>{
let {username , password} =req.body
   let createuser = await usermodel.create({
        username ,
        password 
    })
    res.json(createuser)
})
//creating books
    app.post('/createbooks',  async (req,res)=>{
        let {booktitle,author ,Category,description,image} =req.body
        let createbooks = await Bookmodel.create({
            booktitle,
            author ,
            Category,
            description,
            image
            })
            
            res.redirect('/student')
        })
        app.get('/student',async (req,res)=>{
            let book = await Bookmodel.find()
            res.render('student_home_page' , {book})
   // delete books 
    app.get('/delete/:id' , async (req,res)=>{
      let  books = await Bookmodel.findOneAndDelete({_id:req.params.id})
        res.redirect('/student')
    })
   
    

 
})
app.get('/librarian',(req,res)=>{
    res.render('librarian_home_page')
})
app.get('/student/cart',(req,res)=>{
    res.render('cart')
})

app.listen(3000)




























// const login_text = document.getElementById('login_text');
//         const switch_btn = document.getElementById('switch');
//         const switch_btn_student = document.getElementById('switch_student');
//         const login_btn = document.getElementById('login_btn');

//         let isStudentLogin = true; 

//         switch_btn.addEventListener('click', () => {
//             login_text.innerText = "Librarian Login";
//             switch_btn.hidden = true;
//             switch_btn_student.hidden = false;
//             isStudentLogin = false;
//         });

//         switch_btn_student.addEventListener('click', () => {
//             login_text.innerText = "Student Login";
//             switch_btn.hidden = false;
//             switch_btn_student.hidden = true;
//             isStudentLogin = true;
//         });

//         login_btn.addEventListener('click', () => {
//             if (isStudentLogin) {
//                 alert("Redirecting to Student Login...");
//                 window.location.href = 'student_home_page.html';
//             } else {
//                 alert("Redirecting to Librarian Login...");
//                 window.location.href = 'librarian_home_page.html';
//             }
//         });